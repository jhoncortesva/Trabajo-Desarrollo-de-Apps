import { Component } from '@angular/core';

@Component({
  selector: 'app-segundapagina',
  standalone: true,
  imports: [],
  templateUrl: './segundapagina.component.html',
  styleUrl: './segundapagina.component.css'
})
export class SegundapaginaComponent {

}
