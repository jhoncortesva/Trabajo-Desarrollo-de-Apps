import { Component } from '@angular/core';

@Component({
  selector: 'app-cuartapagina',
  standalone: true,
  imports: [],
  templateUrl: './cuartapagina.component.html',
  styleUrl: './cuartapagina.component.css'
})
export class CuartapaginaComponent {

}
