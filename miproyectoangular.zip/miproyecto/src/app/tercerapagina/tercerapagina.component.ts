import { Component } from '@angular/core';

@Component({
  selector: 'app-tercerapagina',
  standalone: true,
  imports: [],
  templateUrl: './tercerapagina.component.html',
  styleUrl: './tercerapagina.component.css'
})
export class TercerapaginaComponent {

}
