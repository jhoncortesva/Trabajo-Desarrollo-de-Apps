import { Component } from '@angular/core';

@Component({
  selector: 'app-pagesabout',
  standalone: true,
  imports: [],
  templateUrl: './pagesabout.component.html',
  styleUrl: './pagesabout.component.css'
})
export class PagesaboutComponent {

}
